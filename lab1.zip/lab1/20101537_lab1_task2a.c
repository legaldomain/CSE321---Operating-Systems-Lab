#include<stdio.h>
int main()
{  
    int x,y;
    printf("enter value:");
    scanf("%d %d",&x,&y);
    if(x>y)
        printf("%d\n",x-y);
    else if(x<y)
        printf("%d\n",x+y);

    else
        printf("%d\n",x*y);
    
}
