#include<stdio.h>
#include<string.h>
char ch[1000000];
int main()
{  
    char s[1000000];
    printf("Enter email address: ");  
    scanf("%s",s);
    int len=strlen(s);
    int count=0;
    int j=0;
    for(int i=0;i<len;i++)
    {
        if(s[i]=='@')
            count=1;
        else if (count==1)
        {
            ch[j]=s[i];
            j++;
            
        }
    }
    int value=strcmp(ch,"kaaj.com");
    if(value==0)
        printf("Email address is outdated");
    int value1=strcmp(ch,"sheba.xyz");
    if(value1==0)
        printf("Email address is okay");
    printf("\n");
    return 0;  
}
