#include<stdio.h>
#include<string.h>
int main()
{  
    char s[1000000];
    printf("Enter the string: ");  
    scanf("%s",s);
    int len=strlen(s);
    int upper=0,lower=0,digit=0,special=0;
    for(int i=0;i<len;i++)
    {
        if(s[i]>='A' && s[i]<='Z')
            upper++;
        else if(s[i]>='a' && s[i]<='z')
            lower++;
        else if (s[i]>='0' && s[i]<='9')
            digit++;
        else if (s[i]=='_' ||s[i]=='$' ||s[i]=='#' ||s[i]=='@' )
            special++;
    }
    if (upper==0 || lower==0 || digit==0 || special==0)
    {
    if(upper==0)
        printf("Uppercase character missing,");
    if(lower==0)
        printf("Lowercase character missing,");
    if(digit==0)
        printf("Digit missing,");
    if(special==0)
        printf("Special character missing,");
    printf("\b");
    }
    else if (upper!=0 && lower!=0 && digit!=0 && special!=0)
        printf("password is okay! good job");
  
    return 0;  
}