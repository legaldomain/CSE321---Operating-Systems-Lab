#include<stdio.h>
#include<string.h>
int main()
{  
    char s[1000000];
    printf("Enter the string: ");  
    scanf("%s",s);
    int len=strlen(s);

    for(int i=0;i<len/2;i++)
    {
        if(s[i]!=s[len-i-1])
        {
            printf("Not Palindrome\n");
            return 0;
        }
    }
    printf("Palindrome\n");
    return 0;  
}
