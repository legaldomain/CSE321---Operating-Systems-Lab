#include<stdio.h>
#include<string.h>
main(){

    int n = 15;
    float f =2.4;
    char s[1000000];
    //char s = 'valorant';

    printf("%d\n",n);
    printf("%f\n",f);
    printf("%c",'valorant');




}