#include<stdio.h>
#include<string.h>
char ch[1000000];
int main()
{  
    char s[1000000];
    
    FILE *file;
    file=fopen("input.txt","r");
    fscanf(file,"%[^\n]s",s);
    fclose(file);
    int len=strlen(s);
    int count=0;
    int j=0;
    for(int i=0;i<len;i++)
    {
        if(s[i]==' ')
            count++;

        else if((s[i]>='A' && s[i]<='Z') ||  (s[i]>='a' && s[i]<='z'))
        {
            ch[j]=s[i];
            j++;
            count=0;
        }
        if(count==1)
        {
            ch[j]=s[i];
            j++;
        }
    }
    int len1=strlen(ch);
    FILE *file1;
    file1=fopen("output.txt","w");
    for(int i=0;i<len1;i++)
    {
        fprintf(file1,"%c",ch[i]);
    }
    fprintf(file1,"\n");
    fclose(file1);

    return 0;  ;
}