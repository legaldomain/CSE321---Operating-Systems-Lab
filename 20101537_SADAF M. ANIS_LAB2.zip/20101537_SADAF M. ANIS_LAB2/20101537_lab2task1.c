#include<stdio.h>
struct resturant
{
    float quantity;
    float unit;
}paratha,veg,water;


int main()
{
    printf("Quantity Of Parathas: ");
    scanf("%f",&paratha.quantity);
    printf("Unit Price: ");
    scanf("%f",&paratha.unit);
    printf("Quantity Of Vegetables: ");
    scanf("%f",&veg.quantity);
    printf("Unit Price: ");
    scanf("%f",&veg.unit);
    printf("Quantity Of Mineral Water: ");
    scanf("%f",&water.quantity);
    printf("Unit Price: ");
    scanf("%f",&water.unit);
    float n;
    printf("Number of People: ");
    scanf("%f",&n);
    float avg=((paratha.quantity*paratha.unit)+(veg.quantity*veg.unit)+(water.quantity*water.unit))/n;
    printf("Individual people will pay: %.2f tk\n",avg);

}