#include <stdio.h>

#define MAX_SIZE 100

int compare(const void *a, const void *b) {
    return (*(int *)b - *(int *)a);
}

int main() {
    int nums[MAX_SIZE];
    int size;

    printf("Enter the number of elements: ");
    scanf("%d", &size);

    if (size <= 0 || size > MAX_SIZE) {
        printf("Invalid input size\n");
        return 1;
    }

    printf("Enter %d elements: ", size);
    for (int i = 0; i < size; i++) {
        scanf("%d", &nums[i]);
    }

    // Sorting the array in descending order
    qsort(nums, size, sizeof(int), compare);

    printf("Sorted Array in Descending Order:\n");
    for (int i = 0; i < size; i++) {
        printf("%d ", nums[i]);
    }
    printf("\n");

    return 0;
}
