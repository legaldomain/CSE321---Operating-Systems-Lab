#include<stdio.h>
#include <stdbool.h>
#include<string.h>
#include<stdlib.h>
char ch[100];
int main(int args,char *arg[])
{
    FILE *file;
    int i=0;
    file=fopen(arg[1],"w");
    char ch[100];
    scanf("%s",ch);
    while (true)
    {
        
        bool check=true;
        for(int i=0;i<strlen(ch)-1;i++)
        {
            if(ch[i]=='-' && ch[i+1]=='1')
                {
                    check=false;
                    break;
                }
        }
        if(check==false)
            break;
        fprintf(file,"%s\n",ch);
        scanf("%s",ch);
    }
    fclose(file);
    return 0;  
}