#include<stdio.h>
#include <stdlib.h>
#include <unistd.h>
int main()
{
    int ppid,cpid;
    int ppidno,cpidno,gpid1no,gpid2no,gpid3no;
    ppid=fork();
    if(ppid==0)
    {
       cpid=fork();
       if(cpid==0)
       {
            gpid1no=getpid();
            gpid2no=getpid();
            gpid3no=getpid();
            

       }
       else
       {
           sleep(2);
           cpidno=getpid();
       }
    }
    else
    {
        sleep(3);
        ppidno=getpid();
        printf("1. Parent process ID : %d\n",ppidno);
        printf("2. Child process ID : %d\n",cpidno);
        printf("3. Grand Child process ID : %d\n",gpid1no);
        printf("4. Grand Child process ID : %d\n",gpid2no);
        printf("5. Grand Child process ID : %d\n",gpid3no);
    }
    
}