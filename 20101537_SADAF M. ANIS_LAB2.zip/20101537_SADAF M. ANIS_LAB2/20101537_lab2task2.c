#include<stdio.h>
int perfect(int num)
{
    int sum=0;
    for(int i=1;i<num;i++)
    {
        if(num%i==0)
            sum+=i;
    }
    if(sum==num)
        return 1;
    return 0;

}
int main()
{
    int start,end;
    scanf("%d %d",&start,&end);
    for(int i=start;i<=end;i++)
    {
        int x=perfect(i);
        if(x==1)
            printf("%d\n",i);
    }
}
