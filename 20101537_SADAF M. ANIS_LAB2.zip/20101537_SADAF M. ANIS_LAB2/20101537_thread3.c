#include<stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include<pthread.h>
#include<string.h>


void *cASCII(void *str1)
{
    char* str=(char*)str1;
    int *n=malloc(sizeof(int));
    int sum=0;
    for(int i=0;i<strlen(str);i++)
    {
        sum+=str[i];
    }
    *n=sum;
    return (void*)n;
    pthread_exit(NULL);
}

int main()
{
    char name1[1000],name2[1000],name3[1000];
    scanf("%s %s %s",name1,name2,name3);
    pthread_t ptd1,ptd2,ptd3;
    pthread_create(&ptd1,NULL,cASCII,name1);
    int *ptr1;
    pthread_join(ptd1,(void**)&ptr1);
    pthread_create(&ptd2,NULL,cASCII,name2);
    int *ptr2;
    pthread_join(ptd2,(void**)&ptr2);
    pthread_create(&ptd3,NULL,cASCII,name3);
    int *ptr3;
    pthread_join(ptd3,(void**)&ptr3);

    if(*ptr1==*ptr2 && *ptr1==*ptr3)
        printf("Youreka\n");
    else if(*ptr1==*ptr2 || *ptr1==*ptr3 || *ptr3==*ptr2)
        printf("Miracle\n");
    else
        printf("Hasta la vista\n");

}