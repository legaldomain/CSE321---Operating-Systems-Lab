#include<stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include<pthread.h>

//gcc thread1.c -o thread1 -pthread


void* open(void* p)
{
    printf("thread-%d closing\n",* (int*)p);
    pthread_exit(NULL);
    
}
int main()
{
    pthread_t id[5];
    for(int i=1;i<=5;i++)
    {
        printf("thread-%d running\n",i);
        pthread_create(&id[i],NULL,open,&i);
        int* ptr;
        pthread_join(id[i],(void**)&ptr);
    }
    return 0;
}