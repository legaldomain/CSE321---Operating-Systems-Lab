#include<stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include<math.h> 
int main()
{
    int parent,child,pid,count=0;
    parent=fork();
    count++;
    if(parent==0)
    {
        pid=getpid();
        printf("pid is: %d",pid);
        if(pid%2==0)
        {
            child=fork();
            count++;
            
        }
        
    }
    else
    {
        sleep(3);
        double x=pow((double)2,(double)count);
        printf("\nprocess created  : %d\n",(int)x);
        
    }
    
}