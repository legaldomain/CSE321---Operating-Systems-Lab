#include<stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include<pthread.h>
int count=1;


void* open(void* p)
{
    for(int i=1;i<=5;i++)
    {
        printf("thread-%d prints %d\n",* (int*)p+1,count);
        count++;
    }
    pthread_exit(NULL);
    


}
int main()
{
    pthread_t id[5];
    for(int i=0;i<5;i++)
    {
        
        pthread_create(&id[i],NULL,open,&i);
        int* ptr;
        pthread_join(id[i],(void**)&ptr);
    }
    return 0;
}