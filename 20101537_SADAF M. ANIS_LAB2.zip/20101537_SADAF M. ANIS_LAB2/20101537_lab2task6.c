#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

#define MAX_SIZE 100

int main() {
    int nums[MAX_SIZE];
    int size;

    printf("Enter the number of elements: ");
    scanf("%d", &size);

    if (size <= 0 || size > MAX_SIZE) {
        printf("Invalid input size\n");
        return 1;
    }

    printf("Enter %d elements: ", size);
    for (int i = 0; i < size; i++) {
        scanf("%d", &nums[i]);
    }

    pid_t pid = fork();

    if (pid < 0) {
        fprintf(stderr, "Fork failed\n");
        return 1;
    } else if (pid == 0) { // Child process
        printf("Child Process:\n");

        // Sorting the array in ascending order
        for (int i = 0; i < size - 1; i++) {
            for (int j = 0; j < size - 1 - i; j++) {
                if (nums[j] > nums[j + 1]) {
                    int temp = nums[j];
                    nums[j] = nums[j + 1];
                    nums[j + 1] = temp;
                }
            }
        }

        printf("Sorted Array in Ascending Order:\n");
        for (int i = 0; i < size; i++) {
            printf("%d ", nums[i]);
        }
        printf("\n");
    } else { // Parent process
        wait(NULL);
        printf("Parent Process:\n");

        printf("Odd/Even Status:\n");
        for (int i = 0; i < size; i++) {
            if (nums[i] % 2 == 0)
                printf("%d: Even\n", nums[i]);
            else
                printf("%d: Odd\n", nums[i]);
        }
    }

    return 0;
}
