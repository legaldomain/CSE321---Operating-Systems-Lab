#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
  
int main()
{
    int parent,child,grandchild;
    child=fork();
    if(child==0)
    {
        
        grandchild=fork();
        if(grandchild==0)
        {
            printf("I am grandchild\n");
            
        }
        else
        {
            sleep(1);
            printf("I am child\n");
        }
    }
    else
    {
        sleep(3);
        printf("I am parent\n");
    }
    
}