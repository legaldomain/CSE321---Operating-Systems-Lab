#include <stdio.h>

#define MAX_SIZE 100

int main() {
    int nums[MAX_SIZE];
    int size;

    printf("Enter the number of elements: ");
    scanf("%d", &size);

    if (size <= 0 || size > MAX_SIZE) {
        printf("Invalid input size\n");
        return 1;
    }

    printf("Enter %d elements: ", size);
    for (int i = 0; i < size; i++) {
        scanf("%d", &nums[i]);
    }

    printf("Odd/Even Status:\n");
    for (int i = 0; i < size; i++) {
        if (nums[i] % 2 == 0)
            printf("%d: Even\n", nums[i]);
        else
            printf("%d: Odd\n", nums[i]);
    }

    return 0;
}
